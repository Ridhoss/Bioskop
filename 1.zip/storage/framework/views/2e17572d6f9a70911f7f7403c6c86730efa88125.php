

<?php $__env->startSection('container'); ?>

    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible fade show w-50" role="alert">
            <strong>Booking Failed!</strong> <?php echo e($message); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="movie" id="mov">
        <div class="glider-contain" id="glide">
            <div class="glider p-3" id="in-glide">
                <?php if($count == 0): ?>
                    <h5 class="text-center mt-5">Data Not Found.</h5>
                    <h5 class="text-center mt-5">Data Not Found.</h5>
                    <h5 class="text-center mt-5">Data Not Found.</h5>
                    <h5 class="text-center mt-5">Data Not Found.</h5>
                <?php else: ?>
                    <?php $__currentLoopData = $film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/desc/<?php echo e($f->id); ?>" class="isi">
                            <div class="isi-movie">
                                <img src="<?php echo e(Storage::url('public/film/' . $f->foto)); ?>" class="mb-3">
                                <h1><?php echo e($f->nama); ?></h1>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>

            <button aria-label="Previous" class="glider-prev" id="btn">«</button>
            <button aria-label="Next" class="glider-next" id="btn">»</button>

        </div>
    </div>

    <div class="news" id="news">
        <h1 class="mt-5 mb-5">TIP NEWS</h1>

        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-4">
                <div class="row g-0">
                    <div class="col-md-2">
                        <img src="<?php echo e(Storage::url('public/news/' . $n->foto)); ?>" class="img-fluid rounded-start"
                            style="width: 200px;">
                    </div>
                    <div class="col-md-10">
                        <div class="card-body">
                            <h5 class="card-title mb-3"><?php echo e($n->judul); ?></h5>
                            <p class="card-text"><?php echo e($n->deskripsi); ?></p>
                            <p class="card-text"><small class="text-body-secondary">Uploaded : <?php echo e($n->data_rilis); ?></small>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RIDHO\CODING\Laravel\BIOSKOP\resources\views/users/homeuser.blade.php ENDPATH**/ ?>