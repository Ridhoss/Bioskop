

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <?php if(session()->has('berhasil')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('berhasil')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Detail Order Data</h1>
    
    </div>

    
    <div class="row">
    <table class="table table-stripped mt-2">
        <thead class="table-secondary">
            <th>No</th>
            <th>Order Number</th>
            <th>Ticket Number</th>
            <th>Seat Number</th>
            <th>Price</th>
            <th>Status</th>
            <th colspan="2">Action</th>
        </thead>
        <?php
            $no = 1;
        ?>
        <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($f->no_order); ?></td>
                <td><?php echo e($f->idno_kursi); ?></td>
                <td><?php echo e($f->no_kursi); ?></td>
                <td>Rp. <?php echo e(number_format($f->harga, 0,',','.')); ?></td>
                <td>
                    <form action="/statusDetail" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($f->id); ?>" name="id">
                        <?php if($f->status == '0'): ?>
                            <input type="hidden" value="1" name="go">
                            <button type="submit" class="btn btn-secondary btn-sm">Inactive</button>
                        <?php elseif($f->status == '1'): ?>
                            <input type="hidden" value="0" name="go">
                            <button type="submit" class="btn btn-primary btn-sm">Active</button>
                        <?php endif; ?>
                    </form>
                </td>
                <td>
                    <button class="btn btn-danger btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#hapus<?php echo e($f->id); ?>">Delete</button>
                </td>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>

    

    <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="hapus<?php echo e($g->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Are you sure?</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/hapusdetail" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($g->id); ?>">
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RIDHO\CODING\Laravel\BIOSKOP\resources\views/admin/transaksi/pesandetail.blade.php ENDPATH**/ ?>