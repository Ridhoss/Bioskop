<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TIP Movie Report</title>

    
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body onafterprint="window.location='/order'">

    <div class="container">
        <h1 class="text-center mt-5">TIP MOVIE</h1>
        <p class="text-center">Jl. H. Bakar, Utama, Kec. Cimahi Sel., Kota Cimahi, Jawa Barat 40521</p>

        <div class="row mt-5">
            <p>Date : <?php echo e($start); ?> / <?php echo e($end); ?></p>
            <table class="table table-striped">
                <thead>
                    <th>No</th>
                    <th>Order Number</th>
                    <th>User</th>
                    <th>Film</th>
                    <th>Schedule</th>
                    <th>Teater</th>
                    <th>Broadcast Date</th>
                    <th>Order quantity</th>
                    <th>Total Price</th>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($f->no_order); ?></td>
                            <td><?php echo e($f->username); ?></td>
                            <td><?php echo e($f->film); ?></td>
                            <td><?php echo e($f->start); ?></td>
                            <td><?php echo e($f->nama); ?></td>
                            <td><?php echo e($f->jadwal_tgl); ?></td>
                            <td><?php echo e($f->jml_kursi); ?></td>
                            <td>Rp. <?php echo e(number_format($f->total, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        window.print();
    </script>

</body>

</html>
<?php /**PATH D:\RIDHO\CODING\Laravel\BIOSKOP\resources\views/admin/transaksi/laporan.blade.php ENDPATH**/ ?>