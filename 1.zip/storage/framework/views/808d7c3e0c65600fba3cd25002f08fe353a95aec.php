

<?php $__env->startSection('container'); ?>
    <h1 class="mb-5 fw-bold">Your Ticket</h1>

    <?php $__currentLoopData = $tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/detail-ticket" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="no" value="<?php echo e($tic->no_order); ?>">
            <div class="card mb-5 shadow p-3 mb-5 bg-body-tertiary rounded" style="max-width: 640px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?php echo e(Storage::url('public/film/' . $tic->foto)); ?>" class="img-fluid rounded-start">
                    </div>
                    <div class="col-md-8">
                        <?php
                            $date = date('Y-m-d');
                            
                        ?>
                        <div class="card-body">
                            <?php if($tic->jadwal_tgl < $date): ?>
                                <button class="btn btn-outline-danger btn-sm mb-4 disabled" style="float: right;"
                                    onclick="GenerateQR()">Expired</button>
                            <?php else: ?>
                                <button class="btn btn-outline-success btn-sm mb-4 disabled" style="float: right;"
                                    onclick="GenerateQR()">Active</button>
                            <?php endif; ?>

                            <h6 class="card-title text-secondary">No Order : <?php echo e($tic->no_order); ?></h6>
                            <h1 class="card-title mt-3 text-uppercase mb-4 fw-bold"><?php echo e($tic->film); ?></h1>
                            <h6 class="text-secondary"><i class="fa-solid fa-calendar-days me-2"></i>Schedule :
                                <?php echo e($tic->jadwal); ?></h6>
                            <h6 class="text-secondary"><i class="fa-solid fa-house me-2"></i>Teater : <?php echo e($tic->teater); ?>

                            </h6>
                            <h6 class="text-secondary"><i class="fa-solid fa-dollar-sign me-2"></i>Price : Rp.
                                <?php echo e(number_format($tic->total, 0, ',', '.')); ?></h6>
                            <p class="card-text mt-4"><small class="text-body-secondary">Date :
                                    <?php echo e($tic->tgl_trans); ?></small></p>

                            <?php if($tic->jadwal_tgl < $date): ?>
                                <button class="btn btn-primary disabled" style="float: right;" onclick="GenerateQR()">View</button>
                            <?php else: ?>
                                <button class="btn btn-primary" style="float: right;" onclick="GenerateQR()">View</button>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RIDHO\CODING\Laravel\BIOSKOP\resources\views/users/ticket.blade.php ENDPATH**/ ?>