

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/assets/css/desc.css">

    <style>
        .col-10 h1 {
            font-weight: 700;
            text-transform: uppercase;
        }

        .col-10 h2 {
            font-size: 18px;
            font-weight: 600;
            color: #6e6e6e;
        }

        .desc > h1{
            text-transform: uppercase;
        }

        .desc > p {
            font-family: 'Comfortaa', cursive;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <div class="main">
        <div class="main-desc">
            <img src="<?php echo e(Storage::url('public/film/' . $film->foto)); ?>">
            <div class="desc">
                <h1><?php echo e($film->nama); ?></h1>
                <h2>Genre : <?php echo e($film->genre); ?></h2>
                <h2>Duration : <?php echo e($film->durasi); ?></h2>
                <p><?php echo e($film->deskripsi); ?></p>

                <form action="/book" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="film" value="<?php echo e($film->id); ?>">

                    <div class="pnl">
                        <h1>Teater : </h1>
                        <div class="row">
                            <?php $__currentLoopData = $teater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="radio">
                                    <input type="radio" value="<?php echo e($t->id); ?>" name="teater" required>
                                    <h1><i class="fa-solid fa-film me-2"></i><?php echo e($t->nama); ?></h1>
                                    <p><i class="fa-solid fa-dollar-sign me-2"></i>Rp.
                                        <?php echo e(number_format($t->harga, 0, ',', '.')); ?></p>
                                    <span></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php
                            $today = date('Y-m-d');
                        ?>
                        <h6 class="ms-4 mt-4 fw-bold">Select Date : </h6>
                        <input type="date" class="form-control w-50 ms-3 mb-2" name="tanggal" min="<?php echo e($today); ?>">
                        <button class="btn btn-warning mt-4 ms-3 mb-3" type="submit">Book</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RIDHO\CODING\Laravel\BIOSKOP\resources\views/users/desc.blade.php ENDPATH**/ ?>